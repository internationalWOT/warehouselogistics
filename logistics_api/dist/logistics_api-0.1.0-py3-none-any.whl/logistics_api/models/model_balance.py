# from logistics_api.api.v1_controllers.controller_balance import Balance

# from logistics_api.api.v1_controllers.controller_balance import Balance

class Balance:
    balance = 0