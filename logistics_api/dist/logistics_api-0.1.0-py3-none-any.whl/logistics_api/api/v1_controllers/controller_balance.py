from flask import Flask, render_template, request, jsonify
# from logistics_api import app
from flask_restful import reqparse, abort, Resource
from flask import json, Response
from ...models.model_balance import Balance
from marshmallow import Schema, fields
from webargs.flaskparser import use_args


cache = {"foo":0}

class Balance_Fields(Schema):
    amount = fields.Int(required=True)


class Balance(Resource):
    # get entry
    
    @use_args(Balance_Fields)
    def get(self, args):
        print(args)
        # abort_if_todo_doesnt_exist(todo_id)
        return json.jsonify({'data': 'success'}, 200)
    # delete entry
    def delete(self):
        # abort_if_todo_doesnt_exist(todo_id)
        # del TODOS[todo_id]
        return json.jsonify({'data': 'success1'}, 204)
    # update cell
    def patch(self):
        # args = parser.parse_args()
        # TODOS[todo_id]['task'] = args['task']
        return json.jsonify({'data': 'success1'}, 201)

    def put(self):
        return json.jsonify({'data': 'success'}, 200)

    @use_args(Balance_Fields)
    def post(self, args):
        data = json.dumps(args)
        # print(f'--------------------{test}--------------------')
        # balance = balance + 1
        # myfunc()
        import ipdb; ipdb.set_trace()

        # cache['foo'] = 0
        cache['foo'] = cache['foo'] + 1
        # Balance.balance += 1
        # import ipdb; ipdb.set_trace()
        return Response(json.dumps(
            {'test': str(cache['foo']), 'test2': 'teststring'}), status=201, mimetype='application/json')
