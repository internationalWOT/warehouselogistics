# __version__ = '0.1.0'
# from flask import Flask
# app = Flask(__name__)

# @app.route('/')
# def hello_world():
#     return 'Hello, World!'

# project/__init__.py

from flask import Flask
from flask_restful import Api
from logistics_api.routes.routes import initialize_routes
# from ...logistics_api.Config import config_by_name
from logistics_api.configuration import config_by_name


def create_app(config_name: str) -> Flask:
    """
    Application factory, creates and configure the Flask application.
    """
    app = Flask(__name__)
    api = Api(app)
    
    if not isinstance(config_name, str):
        config_name = 'dev'

    app.config.from_object(config_by_name[config_name])
    initialize_routes(api)
    # api.
    # app.config.from_object(config_class)

    # a simple page that show all config variables

    return app