from flask import Blueprint, json, Flask
import glob, os
from logistics_api.api.v1_controllers.controller_balance import Balance
# from .Spotify_user_data import api_resources_spotify

# api_resources = Blueprint('api', __name__, url_prefix='/api')

# def initialize_routes() -> Blueprint:
def initialize_routes(api):
    # Blueprint.register_blueprint('api', __name__ , url_prefix="api/v1")
    api.add_resource(Balance, '/balance')
    return api

def register_webresources():
    return ''
    # in the futurem we want to do this dynamically

# @api_resources.route('/')
# def getdata():
#     #TODO add a list of api functionality?
#     return json.dumps({'key': 'value'})
