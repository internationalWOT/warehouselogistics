# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['logistics_api',
 'logistics_api.api.v1_controllers',
 'logistics_api.models',
 'logistics_api.routes']

package_data = \
{'': ['*']}

install_requires = \
['Flask-RESTful>=0.3.9,<0.4.0',
 'Flask>=2.0.1,<3.0.0',
 'ipdb>=0.13.9,<0.14.0',
 'python-dotenv>=0.18.0,<0.19.0',
 'webargs>=8.0.0,<9.0.0']

entry_points = \
{'console_scripts': ['my-script = logistics_api.Setup.py:start']}

setup_kwargs = {
    'name': 'logistics-api',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
